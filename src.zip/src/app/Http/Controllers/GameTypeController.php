<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreGameTypeRequest;
use App\Http\Requests\UpdateGameTypeRequest;
use App\Models\GameType;

class GameTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreGameTypeRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(GameType $gameType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(GameType $gameType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateGameTypeRequest $request, GameType $gameType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(GameType $gameType)
    {
        //
    }
}
